package derson.com.multipletheme;

import android.os.Bundle;
import android.os.PersistableBundle;

import derson.com.multipletheme.colorUi.util.SharedPreferencesMgr;

/**
 * Created by chengli on 15/6/14.
 */
public class SecondActivity extends BaseActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_activity);
    }
}
