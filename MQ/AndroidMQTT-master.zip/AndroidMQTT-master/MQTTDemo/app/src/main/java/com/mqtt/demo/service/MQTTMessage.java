package com.mqtt.demo.service;

/**
 * Created by cym1497 on 2017/7/10.
 */

public class MQTTMessage {
    public String getMessage() {
        return message;
    }

    public String message;

    public void setMessage(String message) {
        this.message = message;
    }
}
