# AndroidMQTT
# digest:Android MQTT Apollo JMS
# to detail http://www.jianshu.com/p/a1f614262cc6
