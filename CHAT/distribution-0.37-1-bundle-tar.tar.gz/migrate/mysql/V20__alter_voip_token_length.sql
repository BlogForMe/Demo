alter table `t_user_session` modify column `_voip_token` varchar(240) DEFAULT '';


