alter table `t_user` add column `_deleted` tinyint DEFAULT 0;
