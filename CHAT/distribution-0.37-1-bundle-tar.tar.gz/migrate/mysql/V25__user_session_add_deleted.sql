alter table `t_user_session` add column `_deleted` tinyint DEFAULT 0;
