insert into t_chatroom (`_cid`, `_title`, `_desc`,`_dt`) values ('chatroom1','火信聊天室1','火信测试聊天室1，用来演示聊天室功能', 1);

insert into t_chatroom (`_cid`, `_title`, `_desc`,`_dt`) values ('chatroom2','火信聊天室2','火信测试聊天室2，用来演示聊天室功能', 1);

insert into t_chatroom (`_cid`, `_title`, `_desc`,`_dt`) values ('chatroom3','火信聊天室3','火信测试聊天室3，用来演示聊天室功能', 1);
