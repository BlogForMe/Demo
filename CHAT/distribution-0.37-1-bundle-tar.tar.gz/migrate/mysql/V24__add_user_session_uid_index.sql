alter table `t_user_session` ADD INDEX `session_uid_index` ( `_uid` );
