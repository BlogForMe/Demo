alter table t_user add column `_createTime` TIMESTAMP default CURRENT_TIMESTAMP;
alter table t_group add column `_createTime` TIMESTAMP default CURRENT_TIMESTAMP;
