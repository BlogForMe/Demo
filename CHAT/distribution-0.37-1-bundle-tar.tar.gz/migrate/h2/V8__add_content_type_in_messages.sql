alter table `t_messages` add column `_content_type` int(11) NOT NULL DEFAULT '0';
