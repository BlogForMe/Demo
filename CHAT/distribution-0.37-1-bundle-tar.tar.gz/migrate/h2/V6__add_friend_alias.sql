
alter table t_friend add column `_alias` varchar(64) DEFAULT NULL;
