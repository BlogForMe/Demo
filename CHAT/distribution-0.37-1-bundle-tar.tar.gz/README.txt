部署方法请参考野火IM开发文档 http://docs.wildfirechat.cn
