export enum InternalError {
  TIMEOUT = "timeout",
  REMOTE_IS_BUSY = "remote is busy",
}

export const AGORA_APP_KEY = "YOUR APP ID";
