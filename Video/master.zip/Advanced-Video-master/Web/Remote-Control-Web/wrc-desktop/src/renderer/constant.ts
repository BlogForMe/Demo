// this address is used to open online website app
export const WRC_WEBSITE = "https://test-remote-control.test.com";

export const AGORA_APP_KEY = "<YOUR APPID>";
