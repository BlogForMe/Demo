#pragma once

#pragma warning(disable:4800)
#pragma warning(disable:4018)
#define WM_GOBACK			WM_USER+100
#define WM_GONEXT			WM_USER+101
#define WM_JOINCHANNEL		WM_USER+200
#define WM_LEAVECHANNEL		WM_USER+201


#define WM_AGSLD_TMBPOSCHANGED	WM_USER+200