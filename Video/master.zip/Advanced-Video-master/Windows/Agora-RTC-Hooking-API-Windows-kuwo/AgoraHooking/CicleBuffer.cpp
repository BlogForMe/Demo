#include "StdAfx.h"
#include "CicleBuffer.h"

CicleBuffer::CicleBuffer(const unsigned int iBufferSize, int waittimeout)
{
	this->m_iBufferSize = iBufferSize;
	this->m_pBuffer = (BYTE*)malloc(iBufferSize);
	this->m_iInternalReadCursor = 0;
	this->m_iInternalWriteCursor = 0;
	this->m_bComplete = FALSE;
	this->m_evtDataAvailable = CreateEvent(NULL, FALSE, FALSE, NULL);
	InitializeCriticalSection(&this->m_csCircleBuffer);
	this->wait_timeout = waittimeout;
}

CicleBuffer::~CicleBuffer(void)
{
	DeleteCriticalSection(&this->m_csCircleBuffer);
	CloseHandle(this->m_evtDataAvailable);
	free(this->m_pBuffer);
}

BOOL CicleBuffer::IsComplete()
{
	return this->m_bComplete;
}

void CicleBuffer::SetComplete()
{
	EnterCriticalSection(&this->m_csCircleBuffer);
	this->m_bComplete = TRUE;
	SetEvent(this->m_evtDataAvailable);
	LeaveCriticalSection(&this->m_csCircleBuffer);
}

unsigned int CicleBuffer::getFreeSize()
{
	unsigned int iNumBytesFree;

	EnterCriticalSection(&this->m_csCircleBuffer);

	if (this->m_iInternalWriteCursor < this->m_iInternalReadCursor)
		iNumBytesFree = (this->m_iInternalReadCursor - 1) - this->m_iInternalWriteCursor;
	else if (this->m_iInternalWriteCursor == this->m_iInternalReadCursor)
		iNumBytesFree = this->m_iBufferSize;
	else
		iNumBytesFree = (this->m_iInternalReadCursor - 1) + (this->m_iBufferSize - this->m_iInternalWriteCursor);

	LeaveCriticalSection(&this->m_csCircleBuffer);
	return iNumBytesFree;
}

unsigned int CicleBuffer::getUsedSize()
{
	return this->m_iBufferSize - this->getFreeSize();
}

void CicleBuffer::flushBuffer()
{
	EnterCriticalSection(&this->m_csCircleBuffer);
	this->m_iInternalReadCursor = 0;
	this->m_iInternalWriteCursor = 0;
	LeaveCriticalSection(&this->m_csCircleBuffer);
}

void CicleBuffer::writeBuffer(const void* pSourceBuffer, const unsigned int iNumBytes)
{
	unsigned int iBytesToWrite = iNumBytes;
	BYTE* pSourceReadCursor = (BYTE*)pSourceBuffer;

	EnterCriticalSection(&this->m_csCircleBuffer);

	//	if (this->m_iInternalWriteCursor >= this->m_iInternalReadCursor)			//2_9 avoid memcpy over
	//	{
	unsigned int iChunkSize = this->m_iBufferSize - this->m_iInternalWriteCursor;
	if (iChunkSize > iBytesToWrite)
		iChunkSize = iBytesToWrite;

	memcpy(this->m_pBuffer + this->m_iInternalWriteCursor, pSourceReadCursor, iChunkSize);
	pSourceReadCursor += iChunkSize;
	iBytesToWrite -= iChunkSize;
	this->m_iInternalWriteCursor += iChunkSize;

	if (this->m_iInternalWriteCursor >= this->m_iBufferSize)
		this->m_iInternalWriteCursor -= this->m_iBufferSize;
	//	}

	if (iBytesToWrite)
	{
		memcpy(this->m_pBuffer + this->m_iInternalWriteCursor, pSourceReadCursor, iBytesToWrite);
		this->m_iInternalWriteCursor += iBytesToWrite;
	}

	SetEvent(this->m_evtDataAvailable);
	LeaveCriticalSection(&this->m_csCircleBuffer);
}

BOOL CicleBuffer::readBuffer(void* pDestBuffer, const unsigned int _iBytesToRead, unsigned int* pbBytesRead)
{
	unsigned int iBytesToRead = _iBytesToRead;
	unsigned int iBytesRead = 0;
	DWORD dwWaitResult;
	BOOL bComplete = FALSE;

	while (iBytesToRead > 0 && bComplete == FALSE)
	{
		dwWaitResult = WaitForSingleObject(this->m_evtDataAvailable, this->wait_timeout);
		if (dwWaitResult == WAIT_TIMEOUT)
		{
			*pbBytesRead = iBytesRead;
			return FALSE;
		}

		EnterCriticalSection(&this->m_csCircleBuffer);

		if (this->m_iInternalReadCursor > this->m_iInternalWriteCursor)
		{
			unsigned int iChunkSize = this->m_iBufferSize - this->m_iInternalReadCursor;
			if (iChunkSize > iBytesToRead)
				iChunkSize = iBytesToRead;

			memcpy((BYTE*)pDestBuffer + iBytesRead, this->m_pBuffer + this->m_iInternalReadCursor, iChunkSize);

			iBytesRead += iChunkSize;
			iBytesToRead -= iChunkSize;

			this->m_iInternalReadCursor += iChunkSize;
			if (this->m_iInternalReadCursor >= this->m_iBufferSize)
				this->m_iInternalReadCursor -= this->m_iBufferSize;
		}

		if (iBytesToRead && this->m_iInternalReadCursor < this->m_iInternalWriteCursor)
		{
			unsigned int iChunkSize = this->m_iInternalWriteCursor - this->m_iInternalReadCursor;
			if (iChunkSize > iBytesToRead)
				iChunkSize = iBytesToRead;

			memcpy((BYTE*)pDestBuffer + iBytesRead,
				this->m_pBuffer + this->m_iInternalReadCursor,
				iChunkSize);

			iBytesRead += iChunkSize;
			iBytesToRead -= iChunkSize;
			this->m_iInternalReadCursor += iChunkSize;
		}

		if (this->m_iInternalReadCursor == this->m_iInternalWriteCursor)
		{
			if (this->m_bComplete)
				bComplete = TRUE;
		}
		else
			SetEvent(this->m_evtDataAvailable);

		LeaveCriticalSection(&this->m_csCircleBuffer);
	}

	*pbBytesRead = iBytesRead;
	return bComplete ? FALSE : TRUE;
}

