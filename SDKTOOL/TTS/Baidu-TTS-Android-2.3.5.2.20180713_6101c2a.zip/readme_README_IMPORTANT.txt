﻿本目录下 tts-debug.apk 可以直接运行

DEMO展示使用合成SDK，如何将文本转为音频数据，并且播放。请先看完界面上的使用说明，之后测试。
打开DEMO界面后，有3个按钮：
  “离在线合成”： SDK合成的功能介绍。
  “保存合成后的音频”： 同“离在线合成”，并且将合成的音频保存为文件。
  “精简版合成”：展示SDK的使用流程。具体集成细节请参考“离在线合成”。

在线文档 ：http://speech.baidu.com/docs/asr/166

集成文档：http://speech.baidu.com/docs/tts/156 及doc_文档目录

请测通DEMO后，了解调用流程及文档后集成。集成的必要修改：http://speech.baidu.com/docs/asr/186

使用Android Studio 最新版本，FILE->OPEN 选本目录 即可打开项目。

问题反馈：
1. QQ群： 在ai.baidu.com 底部可以找到QQ支持群 可以找到百度语音的QQ群号。由于语音的SDK过多， 进入QQ群提问，请讲明Android合成SDK。
2. 论坛:  https://ai.baidu.com/forum/topic/list/166
3. 商务合作及新功能需求  在ai.baidu.com 右侧小图标点击“合作咨询”



SDK及DEMO BUG反馈格式：

1. 现象描述
   调用我们的xxx方法之后，报错。
2. 输入参数：
  
3. 输出结果：
   
4 .用户日志：
  先清空日志，之后调用我们的某个方法结束。请提供给我们之中的完整日志。

5 .手机信息：
   手机型号， android版本号等信息
反馈模板下载：http://bos.nj.bpc.baidu.com/v1/audio/android-tts-feedback-yourContactInfo.zip

DEMO 改进建议及文档建议（有实际方案的，非简单咨询）：
在论坛发帖:  https://ai.baidu.com/forum/topic/list/166 

