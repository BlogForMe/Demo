## Overview

This is an Android Studio reference app for the AndroidBeaconLibrary

## Project Setup

1. Install [Android Studio](https://developer.android.com/sdk/installing/studio.html) 3.1.1
2. Open this project
