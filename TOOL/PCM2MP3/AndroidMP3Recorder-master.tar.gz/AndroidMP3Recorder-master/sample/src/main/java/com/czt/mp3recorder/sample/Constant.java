package com.czt.mp3recorder.sample;

public class Constant {

    public static final int PLAY_MSG = 0;
    public static final int PAUSE_MSG = 1;
    public static final int STOP_MSG = 2;
}
