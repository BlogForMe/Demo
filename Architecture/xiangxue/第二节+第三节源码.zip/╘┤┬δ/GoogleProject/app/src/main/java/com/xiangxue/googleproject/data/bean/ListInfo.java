package com.xiangxue.googleproject.data.bean;

public class ListInfo {
}
