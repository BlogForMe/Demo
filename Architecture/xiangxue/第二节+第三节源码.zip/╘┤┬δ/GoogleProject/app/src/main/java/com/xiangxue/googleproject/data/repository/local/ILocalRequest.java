package com.xiangxue.googleproject.data.repository.local;

/**
 * 为了扩展，这样写（在仓库里面的）
 * 本地获取标准接口（在仓库里面） 也就是本地的数据读取（包括本地数据，等）
 * 只为 LocalRoomRequestManager 服务
 */
public interface ILocalRequest {

    // TODO 可扩展 ...

}
