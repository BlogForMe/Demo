package com.xiangxue.googleproject.data.repository.request;

/**
 * 本地结果集
 */
public class LocalResultData {
}
