package com.xiangxue.googleproject.data.config;

public interface AppConfigs {

    String TAG = "Derry";
    String URL_KEY = "URL_KEY";

}
