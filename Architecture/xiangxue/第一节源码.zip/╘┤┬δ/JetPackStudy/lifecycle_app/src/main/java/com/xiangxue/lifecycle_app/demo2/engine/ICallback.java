package com.xiangxue.lifecycle_app.demo2.engine;

public interface ICallback {

    public void onResumeAction();

    public void onPauseAction();

}
